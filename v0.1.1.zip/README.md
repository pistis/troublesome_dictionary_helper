# Troublesome Dictionary Helper
helper read english

### License
Troublesome Dictionary Helper may be freely distributed under the MIT license.